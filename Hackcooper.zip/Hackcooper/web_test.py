import webbrowser
import random



if __name__ == "__name__":

    url = 'http://www.baidu.com'
    webbrowser.open(url, new = 0 , autoraise = True)
    #print webbrowser.get()

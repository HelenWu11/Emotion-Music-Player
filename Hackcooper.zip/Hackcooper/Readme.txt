README:

1. set up our credentials

2. use python to run this codes

3. and open the home.html to run the codes 
